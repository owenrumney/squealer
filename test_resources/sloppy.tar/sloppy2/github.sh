#!/usr/bin/env bash

GITHUB_TOKEN=4e862a8ec12ef0ad7c1337e8b16d98f4d764b8f6

